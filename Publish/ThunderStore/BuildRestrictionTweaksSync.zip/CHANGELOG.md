<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<li>Updated for Ashlands.</li>
				</ul>
			</td
		<tr>
		<tr>
			<td align="center">1.0.3</td>
			<td align="left">
				<ul>
					<li>Updated Jotunn.</li>
				</ul>
			</td
		<tr>
			<td align="center">1.0.2</td>
			<td align="left">
				<ul>
					<li>Compiled against newest game version.</li>
					<li>Updated README and icon.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.1</td>
			<td align="left">
				<ul>
					<li>Maintenance update.</li>
					<li>Improved shutdown performance.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
